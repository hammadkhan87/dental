import React from 'react'

const Header1 = () => {
  return (
    <div>Header1</div>
  )
}

export default Header1